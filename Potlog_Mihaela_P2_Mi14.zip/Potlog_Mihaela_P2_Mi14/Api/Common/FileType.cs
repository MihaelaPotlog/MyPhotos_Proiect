﻿namespace MyPhotosApi.Api.Constants
{
    static class FileType
    {
        public static bool Video = false;
        public static bool Photo = true;
    }
}
